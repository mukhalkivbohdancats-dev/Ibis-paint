package com.example.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Colorize
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.drawing.DrawingViewModel
import com.example.ui.components.BrushPickerSheet
import com.example.ui.components.BrushSizeDialog
import com.example.ui.components.ColorPaletteSheet
import com.example.ui.components.DrawingCanvas
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDrawingScreen(
    viewModel: DrawingViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    // Zoom & pan state
    var zoomScale by remember { mutableStateOf(1.0f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }

    // Toast notification for saving
    LaunchedEffect(uiState.saveMessage) {
        uiState.saveMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearSaveMessage()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF131418))
    ) {
        // Core Drawing Canvas
        DrawingCanvas(
            engine = viewModel.engine,
            brushType = uiState.selectedBrush,
            brushColor = uiState.selectedColor,
            brushSize = uiState.brushSize,
            brushOpacity = uiState.brushOpacity,
            isEraser = uiState.isEraser,
            isEyedropperActive = uiState.isEyedropperActive,
            zoomScale = zoomScale,
            panOffset = panOffset,
            onCanvasSizeReady = { width, height ->
                viewModel.initializeEngine(width, height)
            },
            onStrokeFinished = {
                viewModel.updateUndoRedoStatus()
            },
            onColorPicked = { pickedColor ->
                viewModel.selectColor(pickedColor)
                viewModel.toggleEyedropper()
                Toast.makeText(context, "Колір обрано піпеткою!", Toast.LENGTH_SHORT).show()
            },
            onTransform = { zoomChange, panChange ->
                zoomScale = (zoomScale * zoomChange).coerceIn(0.5f, 6.0f)
                panOffset += panChange
            },
            modifier = Modifier.fillMaxSize()
        )

        // Eyedropper indicator banner
        AnimatedVisibility(
            visible = uiState.isEyedropperActive,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 56.dp)
        ) {
            Surface(
                color = Color(0xFF00E5FF),
                shape = RoundedCornerShape(20.dp),
                shadowElevation = 6.dp,
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Colorize,
                        contentDescription = null,
                        tint = Color(0xFF121316),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Торкніться полотна, щоб вибрати колір",
                        color = Color(0xFF121316),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Top Studio Bar
        TopStudioBar(
            canUndo = uiState.canUndo,
            canRedo = uiState.canRedo,
            zoomScale = zoomScale,
            onUndo = { viewModel.undo() },
            onRedo = { viewModel.redo() },
            onResetZoom = {
                zoomScale = 1.0f
                panOffset = Offset.Zero
            },
            onClear = { viewModel.setShowClearDialog(true) },
            onSave = { viewModel.saveDrawingToGallery(context) },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )

        // Bottom Studio Dock (Ibis Paint controls: Brushes, 50 Colors, 1-1000px Size, Opacity)
        BottomStudioDock(
            selectedBrush = uiState.selectedBrush,
            brushSize = uiState.brushSize,
            brushColor = uiState.selectedColor,
            brushOpacity = uiState.brushOpacity,
            isEraser = uiState.isEraser,
            isEyedropperActive = uiState.isEyedropperActive,
            onBrushClick = { viewModel.setShowBrushSheet(true) },
            onSizeClick = { viewModel.setShowSizeDialog(true) },
            onColorClick = { viewModel.setShowColorSheet(true) },
            onEraserToggle = { viewModel.toggleEraser() },
            onEyedropperToggle = { viewModel.toggleEyedropper() },
            onSizeStep = { delta ->
                viewModel.setBrushSize(uiState.brushSize + delta)
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }

    // Modal Sheet: 10 Brushes Picker
    if (uiState.showBrushSheet) {
        BrushPickerSheet(
            selectedBrush = uiState.selectedBrush,
            currentColor = uiState.selectedColor,
            onBrushSelect = { viewModel.selectBrush(it) },
            onDismiss = { viewModel.setShowBrushSheet(false) }
        )
    }

    // Modal Sheet: 50 Colors Palette
    if (uiState.showColorSheet) {
        ColorPaletteSheet(
            selectedColor = uiState.selectedColor,
            brushOpacity = uiState.brushOpacity,
            recentColors = uiState.recentColors,
            onColorSelect = { viewModel.selectColor(it) },
            onOpacityChange = { viewModel.setBrushOpacity(it) },
            onEyedropperClick = { viewModel.toggleEyedropper() },
            onDismiss = { viewModel.setShowColorSheet(false) }
        )
    }

    // Dialog: Brush Size (1 to 1000 px) with Direct Numeric Input
    if (uiState.showSizeDialog) {
        BrushSizeDialog(
            currentSize = uiState.brushSize,
            brushColor = if (uiState.isEraser) Color.White else uiState.selectedColor,
            onSizeChange = { viewModel.setBrushSize(it) },
            onDismiss = { viewModel.setShowSizeDialog(false) }
        )
    }

    // Dialog: Clear Canvas Confirmation
    if (uiState.showClearDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowClearDialog(false) },
            containerColor = Color(0xFF22242D),
            title = {
                Text(
                    text = "Очистити полотно?",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Ви впевнені, що хочете видалити всі малюнки з полотна? Цю дію можна буде скасувати стрілкою назад.",
                    color = Color(0xFFC4C8D8)
                )
            },
            confirmButton = {
                TextButton(
                    onClick = { viewModel.clearCanvas() }
                ) {
                    Text(
                        text = "Очистити",
                        color = Color(0xFFFF5252),
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowClearDialog(false) }) {
                    Text(text = "Скасувати", color = Color(0xFF9E9E9E))
                }
            }
        )
    }
}

@Composable
fun TopStudioBar(
    canUndo: Boolean,
    canRedo: Boolean,
    zoomScale: Float,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onResetZoom: () -> Unit,
    onClear: () -> Unit,
    onSave: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .shadow(8.dp, RoundedCornerShape(16.dp))
            .testTag("top_studio_bar"),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF1E2028).copy(alpha = 0.94f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // App Title & Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF00E5FF)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Brush,
                        contentDescription = null,
                        tint = Color(0xFF101216),
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Ibis Paint",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "50 кольорів • 10 щіток",
                        color = Color(0xFF8B8E9E),
                        fontSize = 10.sp
                    )
                }
            }

            // Quick Actions: Undo, Redo, Zoom, Clear, Save
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Undo
                IconButton(
                    onClick = onUndo,
                    enabled = canUndo,
                    modifier = Modifier.size(36.dp).testTag("undo_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Undo,
                        contentDescription = "Скасувати",
                        tint = if (canUndo) Color.White else Color(0xFF4A4E5E)
                    )
                }

                // Redo
                IconButton(
                    onClick = onRedo,
                    enabled = canRedo,
                    modifier = Modifier.size(36.dp).testTag("redo_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Redo,
                        contentDescription = "Повторити",
                        tint = if (canRedo) Color.White else Color(0xFF4A4E5E)
                    )
                }

                // Zoom reset badge / button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (zoomScale != 1.0f) Color(0xFF2E3240) else Color.Transparent)
                        .clickable { onResetZoom() }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                        .testTag("reset_zoom_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CenterFocusStrong,
                            contentDescription = "Масштаб",
                            tint = if (zoomScale != 1.0f) Color(0xFF00E5FF) else Color(0xFF8B8E9E),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${(zoomScale * 100).roundToInt()}%",
                            color = if (zoomScale != 1.0f) Color(0xFF00E5FF) else Color(0xFF8B8E9E),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Clear
                IconButton(
                    onClick = onClear,
                    modifier = Modifier.size(36.dp).testTag("clear_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Очистити",
                        tint = Color(0xFFFF5252)
                    )
                }

                // Save PNG
                IconButton(
                    onClick = onSave,
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0xFF282C38), CircleShape)
                        .testTag("save_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Зберегти в галерею",
                        tint = Color(0xFF00E5FF)
                    )
                }
            }
        }
    }
}

@Composable
fun BottomStudioDock(
    selectedBrush: com.example.model.BrushType,
    brushSize: Float,
    brushColor: Color,
    brushOpacity: Float,
    isEraser: Boolean,
    isEyedropperActive: Boolean,
    onBrushClick: () -> Unit,
    onSizeClick: () -> Unit,
    onColorClick: () -> Unit,
    onEraserToggle: () -> Unit,
    onEyedropperToggle: () -> Unit,
    onSizeStep: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .shadow(12.dp, RoundedCornerShape(20.dp))
            .testTag("bottom_studio_dock"),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF1A1C24).copy(alpha = 0.96f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Main control row: Brush selector, Direct Size button, Eraser, 50 Colors button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // 1. Brush Selector Button
                Box(
                    modifier = Modifier
                        .weight(1.3f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF252834))
                        .border(1.dp, Color(0xFF353949), RoundedCornerShape(12.dp))
                        .clickable { onBrushClick() }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("brush_selector_button"),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Brush,
                            contentDescription = "Щітка",
                            tint = Color(0xFF00E5FF),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = selectedBrush.nameUk,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "10 видів щіток",
                                color = Color(0xFF8B8E9E),
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // 2. Brush Size (1 - 1000 px) with Direct Numeric Input indicator
                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF252834))
                        .border(1.dp, Color(0xFF353949), RoundedCornerShape(12.dp))
                        .clickable { onSizeClick() }
                        .padding(horizontal = 8.dp, vertical = 8.dp)
                        .testTag("size_picker_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Stepper -
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF323646))
                                .clickable { onSizeStep(-1f) },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Remove,
                                contentDescription = "Зменшити",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }

                        // Size text & edit hint
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(horizontal = 2.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${brushSize.roundToInt()}",
                                    color = Color(0xFF00E5FF),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = " px",
                                    color = Color(0xFFB0B4C4),
                                    fontSize = 11.sp
                                )
                            }
                            Text(
                                text = "ввести ч.",
                                color = Color(0xFF7A7E8F),
                                fontSize = 9.sp
                            )
                        }

                        // Stepper +
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF323646))
                                .clickable { onSizeStep(+1f) },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Збільшити",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // 3. Eraser Toggle
                IconButton(
                    onClick = onEraserToggle,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isEraser) Color(0xFFFF5252) else Color(0xFF252834))
                        .border(
                            1.dp,
                            if (isEraser) Color.White else Color(0xFF353949),
                            RoundedCornerShape(12.dp)
                        )
                        .testTag("eraser_toggle_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoFixHigh,
                        contentDescription = "Гумка",
                        tint = if (isEraser) Color.White else Color(0xFFB0B4C4),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // 4. Color Palette Button (50 colors)
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF252834))
                        .border(1.dp, Color(0xFF353949), RoundedCornerShape(12.dp))
                        .clickable { onColorClick() }
                        .testTag("color_picker_button"),
                    contentAlignment = Alignment.Center
                ) {
                    // Active color circle preview
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(brushColor.copy(alpha = brushOpacity))
                            .border(2.dp, Color.White, CircleShape)
                    )
                }
            }
        }
    }
}
