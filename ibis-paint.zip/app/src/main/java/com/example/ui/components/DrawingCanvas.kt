package com.example.ui.components

import android.view.MotionEvent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntSize
import com.example.drawing.DrawingEngine
import com.example.model.BrushType
import kotlin.math.sqrt

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun DrawingCanvas(
    engine: DrawingEngine?,
    brushType: BrushType,
    brushColor: Color,
    brushSize: Float,
    brushOpacity: Float,
    isEraser: Boolean,
    isEyedropperActive: Boolean,
    zoomScale: Float,
    panOffset: Offset,
    onCanvasSizeReady: (Int, Int) -> Unit,
    onStrokeFinished: () -> Unit,
    onColorPicked: (Color) -> Unit,
    onTransform: (zoomChange: Float, panChange: Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    // Current in-flight stroke points for live smooth preview
    val inProgressPoints = remember { mutableStateListOf<Offset>() }
    var cursorPosition by remember { mutableStateOf<Offset?>(null) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    // Multi-touch tracking for 2-finger zoom/pan vs 1-finger draw
    var isMultiTouching by remember { mutableStateOf(false) }
    var previousDistance by remember { mutableStateOf(0f) }
    var previousCenter by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF16171D))
            .onSizeChanged { size ->
                if (size.width > 0 && size.height > 0) {
                    canvasSize = size
                    onCanvasSizeReady(size.width, size.height)
                }
            }
            .testTag("drawing_canvas_container")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = zoomScale
                    scaleY = zoomScale
                    translationX = panOffset.x
                    translationY = panOffset.y
                }
                .pointerInteropFilter { event ->
                    when (event.pointerCount) {
                        // 2-finger zoom and pan
                        2 -> {
                            isMultiTouching = true
                            inProgressPoints.clear()
                            cursorPosition = null

                            val x0 = event.getX(0)
                            val y0 = event.getY(0)
                            val x1 = event.getX(1)
                            val y1 = event.getY(1)

                            val dx = x0 - x1
                            val dy = y0 - y1
                            val currentDist = sqrt(dx * dx + dy * dy)
                            val currentCenter = Offset((x0 + x1) / 2f, (y0 + y1) / 2f)

                            when (event.actionMasked) {
                                MotionEvent.ACTION_POINTER_DOWN -> {
                                    previousDistance = currentDist
                                    previousCenter = currentCenter
                                }
                                MotionEvent.ACTION_MOVE -> {
                                    if (previousDistance > 0f) {
                                        val zoomFactor = currentDist / previousDistance
                                        val panDelta = currentCenter - previousCenter
                                        onTransform(zoomFactor, panDelta)
                                    }
                                    previousDistance = currentDist
                                    previousCenter = currentCenter
                                }
                                MotionEvent.ACTION_POINTER_UP -> {
                                    previousDistance = 0f
                                }
                            }
                            true
                        }

                        // 1-finger drawing / eyedropper
                        1 -> {
                            if (isMultiTouching) {
                                if (event.actionMasked == MotionEvent.ACTION_UP) {
                                    isMultiTouching = false
                                }
                                return@pointerInteropFilter true
                            }

                            // Convert screen coordinate to canvas coordinate accounting for zoom & pan
                            val canvasX = (event.x - panOffset.x) / zoomScale
                            val canvasY = (event.y - panOffset.y) / zoomScale

                            cursorPosition = Offset(canvasX, canvasY)

                            if (isEyedropperActive) {
                                if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_DOWN) {
                                    engine?.getColorAt(canvasX, canvasY)?.let { picked ->
                                        onColorPicked(picked)
                                    }
                                }
                                return@pointerInteropFilter true
                            }

                            when (event.actionMasked) {
                                MotionEvent.ACTION_DOWN -> {
                                    inProgressPoints.clear()
                                    inProgressPoints.add(Offset(canvasX, canvasY))
                                    engine?.startStroke(canvasX, canvasY)
                                }
                                MotionEvent.ACTION_MOVE -> {
                                    inProgressPoints.add(Offset(canvasX, canvasY))
                                    engine?.continueStroke(canvasX, canvasY)
                                }
                                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                                    engine?.finishStroke(
                                        brushType = brushType,
                                        color = brushColor,
                                        sizePx = brushSize,
                                        opacity = brushOpacity,
                                        isEraser = isEraser
                                    )
                                    inProgressPoints.clear()
                                    cursorPosition = null
                                    onStrokeFinished()
                                }
                            }
                            true
                        }
                        else -> false
                    }
                }
        ) {
            // 1. Draw committed offscreen Bitmap
            engine?.bitmap?.let { bmp ->
                if (!bmp.isRecycled) {
                    drawImage(bmp.asImageBitmap())
                }
            }

            // 2. Draw live active stroke points in real-time
            if (inProgressPoints.isNotEmpty() && !isEyedropperActive) {
                val liveColor = if (isEraser) Color.White else brushColor
                val effectiveLiveAlpha = if (isEraser) {
                    brushOpacity
                } else {
                    brushOpacity * brushType.baseOpacity
                }

                if (inProgressPoints.size == 1) {
                    val p = inProgressPoints[0]
                    drawCircle(
                        color = liveColor.copy(alpha = effectiveLiveAlpha),
                        radius = brushSize / 2f,
                        center = p
                    )
                } else {
                    val livePath = Path()
                    livePath.moveTo(inProgressPoints[0].x, inProgressPoints[0].y)
                    for (i in 1 until inProgressPoints.size) {
                        val prev = inProgressPoints[i - 1]
                        val curr = inProgressPoints[i]
                        val midX = (prev.x + curr.x) / 2f
                        val midY = (prev.y + curr.y) / 2f
                        livePath.quadraticTo(prev.x, prev.y, midX, midY)
                    }

                    // For neon glow live preview
                    if (brushType == BrushType.NEON_GLOW && !isEraser) {
                        drawPath(
                            path = livePath,
                            color = liveColor.copy(alpha = effectiveLiveAlpha * 0.5f),
                            style = Stroke(
                                width = brushSize * 1.6f,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                        drawPath(
                            path = livePath,
                            color = Color.White,
                            style = Stroke(
                                width = (brushSize * 0.35f).coerceAtLeast(1f),
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                    } else {
                        drawPath(
                            path = livePath,
                            color = liveColor.copy(alpha = effectiveLiveAlpha),
                            style = Stroke(
                                width = brushSize,
                                cap = if (brushType.roundCap) StrokeCap.Round else StrokeCap.Square,
                                join = if (brushType.roundCap) StrokeJoin.Round else StrokeJoin.Bevel
                            )
                        )
                    }
                }
            }

            // 3. Draw subtle cursor reticle for brush size preview (1px to 1000px)
            cursorPosition?.let { pos ->
                // Outer outline ring
                val radius = (brushSize / 2f).coerceAtLeast(1f)
                drawCircle(
                    color = Color.Black.copy(alpha = 0.4f),
                    radius = radius + 1f,
                    center = pos,
                    style = Stroke(width = 1.5f)
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.8f),
                    radius = radius,
                    center = pos,
                    style = Stroke(width = 1f)
                )
            }
        }
    }
}
