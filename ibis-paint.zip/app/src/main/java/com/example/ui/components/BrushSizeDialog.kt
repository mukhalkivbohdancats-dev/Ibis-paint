package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Converts linear slider fraction [0..1] to non-linear brush size [1..1000]
 * so low values (1..50 px) have greater precision and travel.
 */
private fun fractionToSize(fraction: Float): Float {
    // Cubic curve: 1 + 999 * (fraction^2.6)
    val size = 1f + 999f * fraction.pow(2.6f)
    return size.coerceIn(1f, 1000f)
}

private fun sizeToFraction(size: Float): Float {
    val clamped = size.coerceIn(1f, 1000f)
    val normalized = (clamped - 1f) / 999f
    return normalized.pow(1f / 2.6f).coerceIn(0f, 1f)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BrushSizeDialog(
    currentSize: Float,
    brushColor: Color,
    onSizeChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    var textValue by remember(currentSize) {
        mutableStateOf(currentSize.roundToInt().toString())
    }
    var isError by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    val presetSizes = listOf(1, 3, 5, 8, 16, 32, 64, 120, 250, 500, 1000)

    fun applyCustomNumber(input: String) {
        val parsed = input.trim().toIntOrNull()
        if (parsed != null && parsed in 1..1000) {
            isError = false
            onSizeChange(parsed.toFloat())
            textValue = parsed.toString()
        } else {
            isError = true
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF1E1F27),
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("brush_size_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Розмір щітки (1 - 1000 px)",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Введіть своє число або оберіть повзунком",
                            color = Color(0xFF9E9E9E),
                            fontSize = 12.sp
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Закрити",
                            tint = Color(0xFFB0B0B0)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Visual Preview Circle
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF14151B)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(110.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Background guide circle
                        Box(
                            modifier = Modifier
                                .size(90.dp)
                                .border(1.dp, Color(0xFF2E313D), CircleShape)
                        )
                        // Dynamic scaled circle preview
                        val previewDp = (currentSize.coerceIn(1f, 1000f) / 1000f * 84f + 4f).dp
                        Box(
                            modifier = Modifier
                                .size(previewDp)
                                .clip(CircleShape)
                                .background(brushColor)
                        )
                        // Overlay size badge
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                                .background(Color(0xFF262832), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${currentSize.roundToInt()} px",
                                color = Color(0xFF00E5FF),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Custom Numeric Input Field
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = {
                            val next = (currentSize - 1f).coerceAtLeast(1f)
                            onSizeChange(next)
                            textValue = next.roundToInt().toString()
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color(0xFF2A2D39), CircleShape)
                            .testTag("size_dec_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "Зменшити на 1",
                            tint = Color.White
                        )
                    }

                    OutlinedTextField(
                        value = textValue,
                        onValueChange = { input ->
                            textValue = input
                            val num = input.toIntOrNull()
                            if (num != null && num in 1..1000) {
                                isError = false
                                onSizeChange(num.toFloat())
                            } else {
                                isError = input.isNotEmpty()
                            }
                        },
                        label = { Text("Введіть розмір (1..1000)", fontSize = 12.sp) },
                        trailingIcon = {
                            Text(
                                text = "px",
                                color = Color(0xFF00E5FF),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(end = 12.dp)
                            )
                        },
                        isError = isError,
                        supportingText = if (isError) {
                            { Text("Введіть число від 1 до 1000", color = Color(0xFFFF5252)) }
                        } else null,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                applyCustomNumber(textValue)
                                focusManager.clearFocus()
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF14151B),
                            unfocusedContainerColor = Color(0xFF14151B),
                            focusedBorderColor = Color(0xFF00E5FF),
                            unfocusedBorderColor = Color(0xFF3B3E4D)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("custom_size_text_field")
                    )

                    IconButton(
                        onClick = {
                            val next = (currentSize + 1f).coerceAtMost(1000f)
                            onSizeChange(next)
                            textValue = next.roundToInt().toString()
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color(0xFF2A2D39), CircleShape)
                            .testTag("size_inc_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Збільшити на 1",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Non-linear Slider (1 to 1000 px)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "1 px", color = Color(0xFF8E8E93), fontSize = 11.sp)
                    Slider(
                        value = sizeToFraction(currentSize),
                        onValueChange = { fraction ->
                            val calculatedSize = fractionToSize(fraction).roundToInt().toFloat()
                            onSizeChange(calculatedSize)
                            textValue = calculatedSize.roundToInt().toString()
                            isError = false
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00E5FF),
                            activeTrackColor = Color(0xFF00E5FF),
                            inactiveTrackColor = Color(0xFF2C2F3C)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 8.dp)
                            .testTag("size_slider")
                    )
                    Text(text = "1000 px", color = Color(0xFF8E8E93), fontSize = 11.sp)
                }

                // Quick Step Modifiers (-10, +10, -100, +100)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf(-100, -10, 10, 100).forEach { delta ->
                        FilledTonalButton(
                            onClick = {
                                val next = (currentSize + delta).coerceIn(1f, 1000f)
                                onSizeChange(next)
                                textValue = next.roundToInt().toString()
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Color(0xFF272935),
                                contentColor = Color(0xFFD0D3E0)
                            ),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text(
                                text = if (delta > 0) "+$delta" else "$delta",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quick Preset Chips (1, 3, 5, 8, 16, 32, 64, 120, 250, 500, 1000)
                Text(
                    text = "Швидкі пресети розміру:",
                    color = Color(0xFF9E9E9E),
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Start
                )
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presetSizes.forEach { preset ->
                        val isSelected = currentSize.roundToInt() == preset
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF00E5FF) else Color(0xFF262832))
                                .border(
                                    1.dp,
                                    if (isSelected) Color.White else Color(0xFF373A48),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    onSizeChange(preset.toFloat())
                                    textValue = preset.toString()
                                    isError = false
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("preset_size_${preset}")
                        ) {
                            Text(
                                text = "$preset px",
                                color = if (isSelected) Color(0xFF101216) else Color.White,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Confirm Button
                Button(
                    onClick = {
                        applyCustomNumber(textValue)
                        onDismiss()
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E5FF),
                        contentColor = Color(0xFF101216)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("confirm_size_button")
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Застосувати (${currentSize.roundToInt()} px)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}
