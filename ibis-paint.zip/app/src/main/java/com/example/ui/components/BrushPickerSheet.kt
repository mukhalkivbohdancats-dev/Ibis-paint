package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BrushType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrushPickerSheet(
    selectedBrush: BrushType,
    currentColor: Color,
    onBrushSelect: (BrushType) -> Unit,
    onDismiss: () -> Unit,
    sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF1E1F27),
        scrimColor = Color.Black.copy(alpha = 0.65f),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(40.dp)
                    .height(4.dp)
                    .background(Color(0xFF424656), CircleShape)
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("brush_picker_sheet")
        ) {
            // Title & close
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "10 видів щіток (Ibis Paint)",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Оберіть стиль штриха та текстуру для малювання",
                        color = Color(0xFF9E9E9E),
                        fontSize = 12.sp
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Закрити",
                        tint = Color(0xFFB0B0B0)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 32.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(BrushType.allBrushes) { brush ->
                    val isSelected = brush == selectedBrush
                    BrushItemRow(
                        brush = brush,
                        currentColor = currentColor,
                        isSelected = isSelected,
                        onClick = {
                            onBrushSelect(brush)
                            onDismiss()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun BrushItemRow(
    brush: BrushType,
    currentColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) Color(0xFF282C3A) else Color(0xFF16171E))
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF2A2D39),
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .padding(14.dp)
            .testTag("brush_item_${brush.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Live Stroke Preview Canvas
            Box(
                modifier = Modifier
                    .size(width = 80.dp, height = 48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0D0E12))
                    .border(1.dp, Color(0xFF22242D), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(width = 72.dp, height = 40.dp)) {
                    drawBrushPreviewSample(brush, currentColor)
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = brush.nameUk,
                        color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = brush.nameEn,
                    color = Color(0xFF8B8E9E),
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = brush.descriptionUk,
                    color = Color(0xFFB0B4C4),
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }

            if (isSelected) {
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Обрано",
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

/**
 * Draws a representative preview stroke curve inside the mini canvas.
 */
private fun DrawScope.drawBrushPreviewSample(brush: BrushType, color: Color) {
    val w = size.width
    val h = size.height
    val strokeColor = color

    val path = Path().apply {
        moveTo(6f, h * 0.7f)
        cubicTo(w * 0.35f, h * 0.1f, w * 0.65f, h * 0.9f, w - 6f, h * 0.3f)
    }

    when (brush) {
        BrushType.FELT_TIP_HARD -> {
            drawPath(
                path = path,
                color = strokeColor,
                style = Stroke(width = 8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
        BrushType.FELT_TIP_SOFT -> {
            drawPath(
                path = path,
                color = strokeColor.copy(alpha = 0.4f),
                style = Stroke(width = 12f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            drawPath(
                path = path,
                color = strokeColor,
                style = Stroke(width = 7f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
        BrushType.DIP_PEN_HARD -> {
            // Tapered look
            drawPath(
                path = path,
                color = strokeColor,
                style = Stroke(width = 6f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
        BrushType.AIRBRUSH_NORMAL -> {
            drawPath(
                path = path,
                color = strokeColor.copy(alpha = 0.25f),
                style = Stroke(width = 16f, cap = StrokeCap.Round)
            )
            drawPath(
                path = path,
                color = strokeColor.copy(alpha = 0.5f),
                style = Stroke(width = 8f, cap = StrokeCap.Round)
            )
        }
        BrushType.AIRBRUSH_SPRAY -> {
            // Spray dots along curve
            for (i in 0..25) {
                val t = i / 25f
                val cx = 6f + (w - 12f) * t
                val cy = h * 0.5f + (kotlin.math.sin(t * Math.PI.toFloat() * 2f)) * (h * 0.3f)
                val jitterX = (kotlin.math.sin(i * 13.5f)) * 8f
                val jitterY = (kotlin.math.cos(i * 19.3f)) * 8f
                drawCircle(
                    color = strokeColor.copy(alpha = 0.65f),
                    radius = 2f,
                    center = Offset(cx + jitterX, cy + jitterY)
                )
            }
        }
        BrushType.DIGITAL_PEN -> {
            drawPath(
                path = path,
                color = strokeColor,
                style = Stroke(width = 6f, cap = StrokeCap.Square, join = StrokeJoin.Miter)
            )
        }
        BrushType.PENCIL_GRAPHITE -> {
            drawPath(
                path = path,
                color = strokeColor.copy(alpha = 0.85f),
                style = Stroke(
                    width = 5f,
                    cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 2f), 0f)
                )
            )
        }
        BrushType.WATERCOLOR_WATER -> {
            drawPath(
                path = path,
                color = strokeColor.copy(alpha = 0.25f),
                style = Stroke(width = 14f, cap = StrokeCap.Round)
            )
            drawPath(
                path = path,
                color = strokeColor.copy(alpha = 0.45f),
                style = Stroke(width = 8f, cap = StrokeCap.Round)
            )
        }
        BrushType.MARKER_FLAT -> {
            drawPath(
                path = path,
                color = strokeColor.copy(alpha = 0.6f),
                style = Stroke(width = 12f, cap = StrokeCap.Square, join = StrokeJoin.Bevel)
            )
        }
        BrushType.NEON_GLOW -> {
            // Outer glow
            drawPath(
                path = path,
                color = strokeColor.copy(alpha = 0.4f),
                style = Stroke(width = 16f, cap = StrokeCap.Round)
            )
            drawPath(
                path = path,
                color = strokeColor.copy(alpha = 0.8f),
                style = Stroke(width = 8f, cap = StrokeCap.Round)
            )
            // Inner core
            drawPath(
                path = path,
                color = Color.White,
                style = Stroke(width = 3f, cap = StrokeCap.Round)
            )
        }
    }
}
