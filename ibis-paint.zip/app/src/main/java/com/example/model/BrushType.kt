package com.example.model

/**
 * 10 distinct brush types inspired by Ibis Paint with characteristic stroke behaviors.
 */
enum class BrushType(
    val id: String,
    val nameUk: String,
    val nameEn: String,
    val descriptionUk: String,
    val baseOpacity: Float,
    val roundCap: Boolean
) {
    FELT_TIP_HARD(
        id = "felt_tip_hard",
        nameUk = "Фломастер (твердий)",
        nameEn = "Felt Tip Pen (Hard)",
        descriptionUk = "Чіткі, насичені лінії з гладким контуром",
        baseOpacity = 1.0f,
        roundCap = true
    ),
    FELT_TIP_SOFT(
        id = "felt_tip_soft",
        nameUk = "Фломастер (м'який)",
        nameEn = "Felt Tip Pen (Soft)",
        descriptionUk = "М'які, шовковисті краї з легким розмиванням",
        baseOpacity = 0.95f,
        roundCap = true
    ),
    DIP_PEN_HARD(
        id = "dip_pen_hard",
        nameUk = "Пір'яна ручка (тверда)",
        nameEn = "Dip Pen (Hard)",
        descriptionUk = "Класичне перо для манги та контурів з конусоподібними кінчиками",
        baseOpacity = 1.0f,
        roundCap = true
    ),
    AIRBRUSH_NORMAL(
        id = "airbrush_normal",
        nameUk = "Аерограф (звичайний)",
        nameEn = "Airbrush (Normal)",
        descriptionUk = "Плавний градієнтний розпил для м'яких тіней і переходів",
        baseOpacity = 0.60f,
        roundCap = true
    ),
    AIRBRUSH_SPRAY(
        id = "airbrush_spray",
        nameUk = "Аерограф (розпилювач)",
        nameEn = "Airbrush (Spray / Spatter)",
        descriptionUk = "Текстурні бризки та зернисті краплі фарби",
        baseOpacity = 0.70f,
        roundCap = true
    ),
    DIGITAL_PEN(
        id = "digital_pen",
        nameUk = "Цифрова ручка",
        nameEn = "Digital Pen",
        descriptionUk = "Піксельна точність без згладжування для піксель-арту та креслень",
        baseOpacity = 1.0f,
        roundCap = false
    ),
    PENCIL_GRAPHITE(
        id = "pencil_graphite",
        nameUk = "Олівець (графітний)",
        nameEn = "Pencil (#2 Graphite)",
        descriptionUk = "Автентична шорстка текстура паперу та графітового грифеля",
        baseOpacity = 0.85f,
        roundCap = true
    ),
    WATERCOLOR_WATER(
        id = "watercolor_water",
        nameUk = "Акварель (водна)",
        nameEn = "Watercolor (Water)",
        descriptionUk = "Напівпрозорі водні мазки з нашаруванням та м'яким краєм",
        baseOpacity = 0.40f,
        roundCap = true
    ),
    MARKER_FLAT(
        id = "marker_flat",
        nameUk = "Маркер (текстовиділяч)",
        nameEn = "Marker / Highlighter",
        descriptionUk = "Напівпрозорий широкий плоский мазок зі зрізаним кінцем",
        baseOpacity = 0.55f,
        roundCap = false
    ),
    NEON_GLOW(
        id = "neon_glow",
        nameUk = "Неонова ручка (сяйво)",
        nameEn = "Neon / Glow Pen",
        descriptionUk = "Яскраве люмінесцентне сяйво навколо білої серцевини",
        baseOpacity = 1.0f,
        roundCap = true
    );

    companion object {
        val allBrushes = values().toList()
    }
}
