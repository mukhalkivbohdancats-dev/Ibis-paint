package com.example.model

import androidx.compose.ui.graphics.Color

/**
 * 50 carefully curated colors inspired by Ibis Paint digital artist palettes,
 * organized into 5 thematic rows of 10 harmonious shades.
 */
object IbisColorPalette {
    data class NamedColor(
        val hex: Long,
        val nameEn: String,
        val nameUk: String
    ) {
        val color: Color get() = Color(hex)
    }

    // Row 1: Grayscale & Neutrals (10 colors)
    val neutrals = listOf(
        NamedColor(0xFF000000, "Pure Black", "Чорний"),
        NamedColor(0xFF1E1E1E, "Charcoal", "Вугільний"),
        NamedColor(0xFF3C3C3C, "Slate Dark", "Темно-сірий"),
        NamedColor(0xFF5A5A5A, "Dim Gray", "Димчасто-сірий"),
        NamedColor(0xFF7D7D7D, "Medium Gray", "Сірий"),
        NamedColor(0xFFA2A2A2, "Silver", "Сріблястий"),
        NamedColor(0xFFC7C7C7, "Light Gray", "Світло-сірий"),
        NamedColor(0xFFE2E2E2, "Platinum", "Платиновий"),
        NamedColor(0xFFF7F7F7, "Pure White", "Білий"),
        NamedColor(0xFFFAF3E0, "Warm Ivory", "Тепла слонова кістка")
    )

    // Row 2: Reds, Corals & Oranges (10 colors)
    val warmTones = listOf(
        NamedColor(0xFF7F0000, "Dark Crimson", "Темно-малиновий"),
        NamedColor(0xFFB71C1C, "Wine Red", "Винний"),
        NamedColor(0xFFD32F2F, "Ruby Red", "Рубіновий"),
        NamedColor(0xFFFF1744, "Vivid Scarlet", "Яскраво-червоний"),
        NamedColor(0xFFFF5252, "Coral Red", "Кораловий"),
        NamedColor(0xFFFF5722, "Deep Orange", "Насичений оранжевий"),
        NamedColor(0xFFFF7043, "Tangerine", "Мандариновий"),
        NamedColor(0xFFFF9800, "Classic Orange", "Помаранчевий"),
        NamedColor(0xFFFFA726, "Warm Amber", "Теплий бурштин"),
        NamedColor(0xFFFFCC80, "Peach", "Персиковий")
    )

    // Row 3: Yellows, Limes & Greens (10 colors)
    val greensAndYellows = listOf(
        NamedColor(0xFFFFD600, "Canary Yellow", "Канарково-жовтий"),
        NamedColor(0xFFFFEE58, "Pastel Yellow", "Пастельно-жовтий"),
        NamedColor(0xFFAEEA00, "Chartreuse", "Шартрез"),
        NamedColor(0xFF76FF03, "Neon Lime", "Неоновий лайм"),
        NamedColor(0xFF4CAF50, "Grass Green", "Трав'яний зелений"),
        NamedColor(0xFF2E7D32, "Forest Green", "Лісовий зелений"),
        NamedColor(0xFF1B5E20, "Deep Pine", "Хвойний"),
        NamedColor(0xFF00BFA5, "Bright Turquoise", "Бірюзовий"),
        NamedColor(0xFF009688, "Teal", "Тіл / Чайне дерево"),
        NamedColor(0xFF004D40, "Dark Emerald", "Темний смарагд")
    )

    // Row 4: Cyans, Blues & Navies (10 colors)
    val blues = listOf(
        NamedColor(0xFF80DEEA, "Soft Cyan", "Світло-блакитний"),
        NamedColor(0xFF00E5FF, "Electric Cyan", "Електричний ціан"),
        NamedColor(0xFF00B0FF, "Sky Blue", "Небесно-блакитний"),
        NamedColor(0xFF2979FF, "Azure Blue", "Лазуровий"),
        NamedColor(0xFF2196F3, "Classic Blue", "Синій"),
        NamedColor(0xFF1565C0, "Cobalt Blue", "Кобальтовий"),
        NamedColor(0xFF0D47A1, "Navy Blue", "Темно-синій"),
        NamedColor(0xFF3D5AFE, "Indigo Electric", "Індиго"),
        NamedColor(0xFF303F9F, "Royal Indigo", "Королівський індиго"),
        NamedColor(0xFF1A237E, "Midnight Blue", "Опівнічно-синій")
    )

    // Row 5: Purples, Pinks & Skin/Earth Tones (10 colors)
    val purplesAndEarth = listOf(
        NamedColor(0xFF4A148C, "Deep Violet", "Глибокий фіолетовий"),
        NamedColor(0xFF7C4DFF, "Bright Purple", "Фіолетовий"),
        NamedColor(0xFFAA00FF, "Electric Magenta", "Пурпуровий"),
        NamedColor(0xFFE040FB, "Neon Fuchsia", "Неонова фуксія"),
        NamedColor(0xFFFF4081, "Hot Pink", "Яскраво-рожевий"),
        NamedColor(0xFFF48FB1, "Pastel Pink", "Ніжно-рожевий"),
        NamedColor(0xFF8D6E63, "Warm Cocoa", "Какао"),
        NamedColor(0xFF5D4037, "Deep Espresso", "Еспресо"),
        NamedColor(0xFFE0C9A6, "Fair Skin Tone", "Світлий тон шкіри"),
        NamedColor(0xFFC68642, "Warm Tan Skin", "Засмаглий тон шкіри")
    )

    /**
     * All 50 colors as a flat list.
     */
    val all50Colors: List<NamedColor> = neutrals + warmTones + greensAndYellows + blues + purplesAndEarth
}
