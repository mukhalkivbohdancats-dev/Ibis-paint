package com.example.drawing

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import com.example.model.BrushType
import com.example.model.IbisColorPalette
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.OutputStream

data class DrawingUiState(
    val selectedBrush: BrushType = BrushType.FELT_TIP_HARD,
    val brushSize: Float = 16f,
    val brushOpacity: Float = 1.0f,
    val selectedColor: Color = Color.Black,
    val isEraser: Boolean = false,
    val isEyedropperActive: Boolean = false,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val showBrushSheet: Boolean = false,
    val showColorSheet: Boolean = false,
    val showSizeDialog: Boolean = false,
    val showClearDialog: Boolean = false,
    val recentColors: List<Color> = listOf(
        Color(0xFF000000),
        Color(0xFFFF1744),
        Color(0xFF2979FF),
        Color(0xFF00E5FF),
        Color(0xFF4CAF50),
        Color(0xFFFFD600),
        Color(0xFF7C4DFF),
        Color(0xFFFFFFFF)
    ),
    val saveMessage: String? = null
)

class DrawingViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(DrawingUiState())
    val uiState: StateFlow<DrawingUiState> = _uiState.asStateFlow()

    var engine: DrawingEngine? = null
        private set

    fun initializeEngine(width: Int, height: Int) {
        if (engine == null || engine?.width != width || engine?.height != height) {
            engine = DrawingEngine(width, height)
            updateUndoRedoStatus()
        }
    }

    fun selectBrush(brush: BrushType) {
        _uiState.value = _uiState.value.copy(
            selectedBrush = brush,
            isEraser = false,
            showBrushSheet = false
        )
    }

    fun setBrushSize(newSize: Float) {
        val clamped = newSize.coerceIn(1f, 1000f)
        _uiState.value = _uiState.value.copy(brushSize = clamped)
    }

    fun setBrushOpacity(opacity: Float) {
        _uiState.value = _uiState.value.copy(brushOpacity = opacity.coerceIn(0.01f, 1.0f))
    }

    fun selectColor(color: Color) {
        val currentRecents = _uiState.value.recentColors.toMutableList()
        currentRecents.remove(color)
        currentRecents.add(0, color)
        if (currentRecents.size > 10) {
            currentRecents.removeAt(currentRecents.lastIndex)
        }

        _uiState.value = _uiState.value.copy(
            selectedColor = color,
            isEraser = false,
            recentColors = currentRecents
        )
    }

    fun toggleEraser() {
        _uiState.value = _uiState.value.copy(
            isEraser = !_uiState.value.isEraser,
            isEyedropperActive = false
        )
    }

    fun toggleEyedropper() {
        _uiState.value = _uiState.value.copy(
            isEyedropperActive = !_uiState.value.isEyedropperActive
        )
    }

    fun setShowBrushSheet(show: Boolean) {
        _uiState.value = _uiState.value.copy(showBrushSheet = show)
    }

    fun setShowColorSheet(show: Boolean) {
        _uiState.value = _uiState.value.copy(showColorSheet = show)
    }

    fun setShowSizeDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showSizeDialog = show)
    }

    fun setShowClearDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showClearDialog = show)
    }

    fun undo() {
        engine?.undo()
        updateUndoRedoStatus()
    }

    fun redo() {
        engine?.redo()
        updateUndoRedoStatus()
    }

    fun clearCanvas() {
        engine?.clearCanvas()
        updateUndoRedoStatus()
        _uiState.value = _uiState.value.copy(showClearDialog = false)
    }

    fun updateUndoRedoStatus() {
        engine?.let {
            _uiState.value = _uiState.value.copy(
                canUndo = it.canUndo,
                canRedo = it.canRedo
            )
        }
    }

    fun clearSaveMessage() {
        _uiState.value = _uiState.value.copy(saveMessage = null)
    }

    fun saveDrawingToGallery(context: Context) {
        val currentBitmap = engine?.bitmap ?: return
        try {
            val filename = "IbisPaint_${System.currentTimeMillis()}.png"
            var fos: OutputStream? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/IbisPaint")
                }
                val imageUri: Uri? = context.contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    contentValues
                )
                imageUri?.let { uri ->
                    fos = context.contentResolver.openOutputStream(uri)
                }
            } else {
                val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val imageFile = java.io.File(imagesDir, filename)
                fos = java.io.FileOutputStream(imageFile)
            }

            fos?.use {
                currentBitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                _uiState.value = _uiState.value.copy(saveMessage = "Малюнок збережено в Галерею!")
            }
        } catch (e: Exception) {
            _uiState.value = _uiState.value.copy(saveMessage = "Помилка збереження: ${e.localizedMessage}")
        }
    }
}
