package com.example.drawing

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.example.model.BrushType
import java.util.Random
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * High-performance drawing engine for Ibis Paint style drawing.
 * Renders into an offscreen Bitmap with support for 10 distinct brush styles,
 * sizes from 1 px to 1000 px, opacity, and eraser.
 */
class DrawingEngine(
    val width: Int,
    val height: Int,
    val backgroundColor: Int = android.graphics.Color.WHITE
) {
    // Primary bitmap and canvas
    var bitmap: Bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
        eraseColor(backgroundColor)
    }
        private set

    private var canvas: Canvas = Canvas(bitmap)

    // In-progress stroke points
    private val currentPoints = mutableListOf<PointF>()
    private val currentPath = Path()
    private val random = Random()

    // Undo / Redo stack (stores bitmap copies, capped to 15 to avoid OOM)
    private val maxHistory = 15
    private val undoStack = ArrayDeque<Bitmap>()
    private val redoStack = ArrayDeque<Bitmap>()

    init {
        saveStateToUndo()
    }

    private fun saveStateToUndo() {
        if (undoStack.size >= maxHistory) {
            val oldest = undoStack.removeFirstOrNull()
            oldest?.recycle()
        }
        undoStack.addLast(bitmap.copy(bitmap.config ?: Bitmap.Config.ARGB_8888, true))
    }

    val canUndo: Boolean get() = undoStack.size > 1
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun undo() {
        if (canUndo) {
            val currentState = undoStack.removeLast()
            redoStack.addLast(currentState)
            val previousState = undoStack.last()
            
            // Restore previous state
            bitmap.recycle()
            bitmap = previousState.copy(previousState.config ?: Bitmap.Config.ARGB_8888, true)
            canvas = Canvas(bitmap)
        }
    }

    fun redo() {
        if (canRedo) {
            val nextState = redoStack.removeLast()
            undoStack.addLast(nextState.copy(nextState.config ?: Bitmap.Config.ARGB_8888, true))
            
            bitmap.recycle()
            bitmap = nextState.copy(nextState.config ?: Bitmap.Config.ARGB_8888, true)
            canvas = Canvas(bitmap)
        }
    }

    fun clearCanvas() {
        saveStateToUndo()
        redoStack.forEach { it.recycle() }
        redoStack.clear()
        bitmap.eraseColor(backgroundColor)
    }

    fun startStroke(x: Float, y: Float) {
        currentPoints.clear()
        currentPoints.add(PointF(x, y))
        currentPath.reset()
        currentPath.moveTo(x, y)
    }

    fun continueStroke(x: Float, y: Float) {
        if (currentPoints.isEmpty()) {
            startStroke(x, y)
            return
        }
        val prev = currentPoints.last()
        // Quadratic bezier smoothing
        val midX = (prev.x + x) / 2f
        val midY = (prev.y + y) / 2f
        currentPath.quadTo(prev.x, prev.y, midX, midY)
        currentPoints.add(PointF(x, y))
    }

    fun finishStroke(
        brushType: BrushType,
        color: Color,
        sizePx: Float,
        opacity: Float,
        isEraser: Boolean
    ) {
        if (currentPoints.isEmpty()) return

        // Clear redo stack on new action
        redoStack.forEach { it.recycle() }
        redoStack.clear()

        // Render the completed stroke onto the canvas
        renderStroke(
            canvas = canvas,
            path = currentPath,
            points = currentPoints,
            brushType = brushType,
            color = color,
            sizePx = sizePx.coerceIn(1f, 1000f),
            opacity = opacity.coerceIn(0.01f, 1f),
            isEraser = isEraser
        )

        // Save new state
        saveStateToUndo()

        currentPoints.clear()
        currentPath.reset()
    }

    /**
     * Renders a stroke according to the specific Ibis Paint brush characteristics.
     */
    fun renderStroke(
        canvas: Canvas,
        path: Path,
        points: List<PointF>,
        brushType: BrushType,
        color: Color,
        sizePx: Float,
        opacity: Float,
        isEraser: Boolean
    ) {
        if (points.isEmpty()) return

        val baseColor = if (isEraser) backgroundColor else color.toArgb()
        val effectiveAlpha = if (isEraser) {
            (opacity * 255).toInt().coerceIn(1, 255)
        } else {
            (opacity * brushType.baseOpacity * 255).toInt().coerceIn(1, 255)
        }

        val paint = Paint().apply {
            this.color = baseColor
            this.alpha = effectiveAlpha
            this.style = Paint.Style.STROKE
            this.isAntiAlias = brushType != BrushType.DIGITAL_PEN
            this.strokeCap = if (brushType.roundCap) Paint.Cap.ROUND else Paint.Cap.SQUARE
            this.strokeJoin = if (brushType.roundCap) Paint.Join.ROUND else Paint.Join.BEVEL
            this.strokeWidth = sizePx
        }

        // Single tap / dot handling
        if (points.size == 1) {
            val p = points[0]
            if (brushType == BrushType.AIRBRUSH_SPRAY) {
                drawSprayDot(canvas, p.x, p.y, sizePx, paint, 35)
            } else {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(p.x, p.y, sizePx / 2f, paint)
            }
            return
        }

        when (brushType) {
            BrushType.FELT_TIP_HARD -> {
                canvas.drawPath(path, paint)
            }

            BrushType.FELT_TIP_SOFT -> {
                val blurRadius = (sizePx * 0.08f).coerceAtLeast(1f)
                paint.maskFilter = BlurMaskFilter(blurRadius, BlurMaskFilter.Blur.NORMAL)
                canvas.drawPath(path, paint)
            }

            BrushType.DIP_PEN_HARD -> {
                // Tapered calligraphy pen
                drawTaperedStroke(canvas, points, sizePx, paint)
            }

            BrushType.AIRBRUSH_NORMAL -> {
                val blurRadius = (sizePx * 0.40f).coerceAtLeast(1.5f)
                paint.maskFilter = BlurMaskFilter(blurRadius, BlurMaskFilter.Blur.NORMAL)
                paint.alpha = (effectiveAlpha * 0.5f).toInt().coerceIn(1, 255)
                canvas.drawPath(path, paint)
            }

            BrushType.AIRBRUSH_SPRAY -> {
                // Particle spray along path points
                drawSprayAlongPath(canvas, points, sizePx, paint)
            }

            BrushType.DIGITAL_PEN -> {
                // Strictly aliased pixel stroke
                paint.isAntiAlias = false
                paint.strokeCap = Paint.Cap.SQUARE
                paint.strokeJoin = Paint.Join.MITER
                canvas.drawPath(path, paint)
            }

            BrushType.PENCIL_GRAPHITE -> {
                // Subtle graphite grain
                paint.strokeCap = Paint.Cap.ROUND
                paint.pathEffect = DashPathEffect(floatArrayOf(sizePx * 0.8f, sizePx * 0.2f), 0f)
                paint.alpha = (effectiveAlpha * 0.85f).toInt().coerceIn(1, 255)
                canvas.drawPath(path, paint)
            }

            BrushType.WATERCOLOR_WATER -> {
                // Soft watery edge with transparency
                val blurRadius = (sizePx * 0.12f).coerceAtLeast(1f)
                paint.maskFilter = BlurMaskFilter(blurRadius, BlurMaskFilter.Blur.SOLID)
                paint.alpha = (effectiveAlpha * 0.45f).toInt().coerceIn(1, 255)
                canvas.drawPath(path, paint)
            }

            BrushType.MARKER_FLAT -> {
                paint.strokeCap = Paint.Cap.SQUARE
                paint.strokeJoin = Paint.Join.BEVEL
                paint.alpha = (effectiveAlpha * 0.60f).toInt().coerceIn(1, 255)
                canvas.drawPath(path, paint)
            }

            BrushType.NEON_GLOW -> {
                if (!isEraser) {
                    // Pass 1: Wide luminous outer glow
                    val glowPaint = Paint(paint).apply {
                        strokeWidth = sizePx * 1.8f
                        val glowBlur = (sizePx * 0.45f).coerceAtLeast(2f)
                        maskFilter = BlurMaskFilter(glowBlur, BlurMaskFilter.Blur.NORMAL)
                        alpha = (effectiveAlpha * 0.75f).toInt().coerceIn(1, 255)
                    }
                    canvas.drawPath(path, glowPaint)

                    // Pass 2: High intensity bright core
                    val corePaint = Paint(paint).apply {
                        strokeWidth = (sizePx * 0.35f).coerceAtLeast(1f)
                        this.color = android.graphics.Color.WHITE
                        alpha = 255
                        maskFilter = null
                    }
                    canvas.drawPath(path, corePaint)
                } else {
                    canvas.drawPath(path, paint)
                }
            }
        }
    }

    private fun drawTaperedStroke(
        canvas: Canvas,
        points: List<PointF>,
        maxSize: Float,
        paint: Paint
    ) {
        val total = points.size
        if (total < 2) return

        for (i in 0 until total - 1) {
            val progress = i.toFloat() / total.toFloat()
            // Taper at start (first 25%) and end (last 25%)
            val widthMultiplier = when {
                progress < 0.25f -> 0.2f + 0.8f * (progress / 0.25f)
                progress > 0.75f -> 0.2f + 0.8f * ((1f - progress) / 0.25f)
                else -> 1.0f
            }
            paint.strokeWidth = (maxSize * widthMultiplier).coerceAtLeast(1f)
            val p1 = points[i]
            val p2 = points[i + 1]
            canvas.drawLine(p1.x, p1.y, p2.x, p2.y, paint)
        }
    }

    private fun drawSprayAlongPath(
        canvas: Canvas,
        points: List<PointF>,
        sizePx: Float,
        paint: Paint
    ) {
        paint.style = Paint.Style.FILL
        val radius = sizePx / 2f
        val density = (sizePx * 0.5f).toInt().coerceIn(10, 80)

        for (i in points.indices step 2) {
            val p = points[i]
            drawSprayDot(canvas, p.x, p.y, sizePx, paint, density)
        }
    }

    private fun drawSprayDot(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        sizePx: Float,
        paint: Paint,
        count: Int
    ) {
        val maxR = sizePx / 2f
        val originalAlpha = paint.alpha
        val particleRadius = (sizePx * 0.04f).coerceIn(1f, 8f)

        for (j in 0 until count) {
            val r = sqrt(random.nextFloat()) * maxR
            val angle = random.nextFloat() * 2f * Math.PI.toFloat()
            val px = cx + r * cos(angle)
            val py = cy + r * sin(angle)

            // Random alpha jitter for spray texture
            paint.alpha = (originalAlpha * (0.4f + 0.6f * random.nextFloat())).toInt().coerceIn(1, 255)
            canvas.drawCircle(px, py, particleRadius, paint)
        }
        paint.alpha = originalAlpha
    }

    /**
     * Eyedropper: reads color at (x, y) coordinates.
     */
    fun getColorAt(x: Float, y: Float): Color? {
        val px = x.toInt()
        val py = y.toInt()
        if (px in 0 until width && py in 0 until height) {
            val pixel = bitmap.getPixel(px, py)
            return Color(pixel)
        }
        return null
    }
}
